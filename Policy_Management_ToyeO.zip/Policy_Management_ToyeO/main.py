#!/usr/bin/env python
# coding: utf-8

# In[4]:


# Import Modules
from policyholder_toye import Policyholder # Imports the Policyholder class from policyholder module
from product_toye import Product   # Imports the product class from the product module
from payment_toye import Payment   # imports payment class from payment module

try:

    # Create sample products products
    product1 = Product(1, "Health Insurance", "Comprehensive health coverage", 500)
    product2 = Product(2, "Life Insurance", "Coverage for life-related risks", 1000)

    # Create sample policyholders
    policyholder1 = Policyholder(101, "Toye Olalekan", "toye_olalekan@gmail.com")
    policyholder2 = Policyholder(102, "Rose Adama", "rose_adama@gmail.com")

    # Create and process payments
    payment1 = Payment(201, policyholder1.policy_id, product1.product_id, product1.price) # payment id 201 with other policy details
    payment2 = Payment(202, policyholder2.policy_id, product2.product_id, product2.price) # payment id 202 with other policy details
    payment1.process_payment()
    payment2.process_payment()

    # Display account details
    print("Policyholder 1 Details:", policyholder1.get_details())
    print("Policyholder 2 Details:", policyholder2.get_details())

    print("Product 1 Details:", product1.get_details())
    print("Product 2 Details:", product2.get_details())

    print("Payment 1 Details:", payment1.get_payment_details())
    print("Payment 2 Details:", payment2.get_payment_details())
    
except ValueError as ve:
    print(f"Value Error: {ve}")
except KeyError as ke:
    print(f"Key Error: {ke}")
except Exception as e:
    print(f"An unexpected error occurred: {e}")


# In[ ]:




