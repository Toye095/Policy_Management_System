#!/usr/bin/env python
# coding: utf-8

# In[ ]:


class Product:            # define product class
    def __init__(self, product_id, name, description, price): # initialize policy holder object
        """
        Initializing new insurance product.
        """
        self.product_id = product_id
        self.name = name
        self.description = description
        self.price = price
        self.active = True

    def update_product(self, name=None, description=None, price=None):  # define method to update product
        """
        Update product details.
        """
        if name:    # Checks for new name value
            self.name = name 
        if description:
            self.description = description
        if price:
            self.price = price
        return f"Product {self.product_id} updated successfully."

    def suspend_product(self):             # Define method to mark the product as inactive
        """
        Suspend the product.
        """
        self.active = False
        return f"Product {self.name} has been suspended."

    def get_details(self):               # Define method to retrieve the product's details as a dictionary
        """
        Return product details as a dictionary.
        """
        return {
            "Product ID": self.product_id,
            "Name": self.name,
            "Description": self.description,
            "Price": self.price,
            "Active": self.active
        }

