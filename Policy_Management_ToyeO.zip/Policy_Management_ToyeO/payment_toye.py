#!/usr/bin/env python
# coding: utf-8

# In[ ]:


class Payment:   # define product class
    def __init__(self, payment_id, policy_id, product_id, amount): # initialize policy holder object
        """
        Initialize a payment record.
        """
        self.payment_id = payment_id
        self.policy_id = policy_id
        self.product_id = product_id
        self.amount = amount
        self.processed = False    # Initialize processed attribute to False to show payment is not yet processed

    def process_payment(self):  # Define method to mark the payment as processed
        """
        Mark the payment as processed.
        """
        if not self.processed:  # Checks that payment has not been processed
            self.processed = True
            return f"Payment {self.payment_id} has been processed."
        return f"Payment {self.payment_id} is already processed."

    def get_payment_details(self):  # Define method to retrieve payment details as a dictionary
        """
        Return payment details as a dictionary.
        """
        return {
            "Payment ID": self.payment_id,
            "Policy ID": self.policy_id,
            "Product ID": self.product_id,
            "Amount": self.amount,
            "Processed": self.processed
        }

