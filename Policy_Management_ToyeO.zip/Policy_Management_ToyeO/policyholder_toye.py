#!/usr/bin/env python
# coding: utf-8

# In[1]:


class Policyholder:       # define policyholder class
    def __init__(self, policy_id, name, email, active=True):    # initialize policy holder object
        """
        Initialize a new policyholder with basic details.
        """
        self.policy_id = policy_id
        self.name = name
        self.email = email
        self.active = active

    def suspend(self):  # define method to suspend policyholder accounts
        """
        Suspend the policyholder's account.
        """
        if self.active:    # checking if policy holder is active
            self.active = False
            return f"Policyholder {self.name} has been suspended."
        return f"Policyholder {self.name} is already suspended."

    def reactivate(self):  # define method to reactivate policyholder's account.
        """
        Reactivate a suspended policyholder account.
        """
        if not self.active: # Checks if policyholder's account is currently inactive
            self.active = True
            return f"Policyholder {self.name} has been reactivated."
        return f"Policyholder {self.name} is already active."

    def get_details(self):  # Define method to retrieve policyholder's details
        """
        Return policyholder details as a dictionary.
        """
        return {                              # returns policy attributes id, name, email and status
            "Policy ID": self.policy_id,
            "Name": self.name,
            "Email": self.email,
            "Active": self.active
        }

